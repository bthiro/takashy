import { motion, useMotionValue, useTransform } from 'framer-motion';

export default function AnimatedViolaAdvanced({ progress }) {
  const float = useMotionValue(0);
  const rotate = useTransform(float, [0, 1], [0, 6]);

  return (
    <motion.svg viewBox="0 0 1000 600">
      <motion.path
        d="M200 100 C320 20 680 20 800 100 C920 180 920 420 800 500 C680 580 320 580 200 500 C80 420 80 180 200 100 Z"
        fill="none"
        stroke="#6b4b2a"
        strokeWidth={8}
        style={{ pathLength: progress }}
      />
    </motion.svg>
  );
}