import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import AnimatedViolaAdvanced from '../components/AnimatedViolaAdvanced';

export default function Home() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref });
  const progress = useTransform(scrollYProgress, [0, 600], [0, 1]);

  return (
    <div ref={ref}>
      <h1>Landing Page Bruno Takashy</h1>
      <AnimatedViolaAdvanced progress={progress} />
    </div>
  );
}