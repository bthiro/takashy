import fs from 'fs';
import path from 'path';

export default async function handler(req, res) {
  if(req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });
  const data = req.body;
  const filePath = path.join(process.cwd(), 'leads.json');
  const existing = fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath)) : [];
  existing.push({ ...data, date: new Date().toISOString() });
  fs.writeFileSync(filePath, JSON.stringify(existing, null, 2));
  res.status(200).json({ success: true });
}